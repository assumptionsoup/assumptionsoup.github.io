Plugin:  Smooth Mesh
Version: 0.1
Author:  Jordan Hueckstaedt
Contact: AssumptionSoup@gmail.com
Website: RubberGuppy.com

Description:
	Smooth Mesh is an open source plugin deformer for Maya written by Jordan Hueckstaedt that averages the verticies of a polygon mesh.  
	Smooth Mesh was written because of the deficiencies in using Maya's average verticies function with rigging.  It was NOT made with 
	modeling in mind and has some rather large drawbacks if you try to use it for that.  It is the first plugin for Maya that I have ever 
	written and should be considered extremely experimental.  With that in mind, if you find any bugs, or are an experienced programmer and 
	notice any inefficiencies or bad practices with my code I would greatly appreciate the feedback!

Features:
	Approximate volume preservation using the Tabuin method.
	Paintable Weights
	Envelope
	Can iterate beyond 20 times.  Take that Maya average verticies!

Limitations:
	Smooth Mesh produces unpredictable results when used to tweak mesh.  As such, it shouldn't be used with modeling.  I realize that 
	this plugin could be extremely useful for modeling, so I asked around on CGTalk for a solution.  Unfortunately, it would seem this 
	is just a byproduct of how deformers work in Maya.  Which makes me really curious how those guys at Kickstand got around this with 
	their Stretch Mesh plugin.  However, since I didn't set out to make a modeling plugin, I'm not terribly upset that I couldn't do this.
	If you happen to know how (and don't mind the code going open source), please let me know!

Usage:
  Applying the Deformer.
	After the plugin is installed and activated select a polygon mesh you wish to apply the deformer to.  Enter the mel command:
		deformer -type smoothMesh;
  Painting weights.
	Painting Weights on the deformer can be brought up through the menu Modify >> Paint Attributes Tool or by right clicking and holding 
	over the mesh and selecting the marking menu Paint >> Smooth Mesh >> SmoothMeshx-weights.
  Operation  
	Laplace is a type of mathematical function and is just your run of the mill smooth mesh operation.  Taubin is the algorithm devised 
	by Gabriel Taubin that can approximate volume preservation.
  Iterations  
	This is the number or iterations to smooth the mesh.  The more iterations there are, the smoother the mesh and the more expensive the
	operation becomes.
  Laplace
	This is the percentage any vertex will move along it's displacement vector towards a single Laplacian smooth iteration.  If you don't
	know what this means, it's safest to leave it alone. At the very least, if you don't know what it does, leave it somewhere below 
	0.6ish since higher values can actually make your mesh unsmooth.
  Volume
	This is the Taubin factor.  It can be used to adjust how much volume is being added back into each iteration.  To know exactly what 
	it's doing, I suggest looking at the source code.

Binaries Included
	The following binaries are included in the Smooth Mesh package.  It's a smattering of versions of Maya that I currently use on my 
	projects.  If you compile Smooth Mesh for a version not included, please send it to me and I'll include it.

	Windows 64
	  2008
	  2009
	  2011
	Windows 64
	  2008 Extension 2
	  2009
	  2011
	  
	Linux 64
	  2008 Extension 2
  
